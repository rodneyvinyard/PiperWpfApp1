﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PiperWpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool _isOriginal = true;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtEnter_Click(object sender, RoutedEventArgs e)
        {
 
        }

        private void btn_3_Enter_or_Exit_Click(object sender, RoutedEventArgs e)
        {
            if (_isOriginal)
            {
                this.txtHitEnter.Content = "ImagineSoftware is a leading provider of medical billing, revenue cycle, and practice management software.";
                this.btn_3_Enter_or_Exit.Content = "Exit";
                _isOriginal = false;

            }
            else
            {
                this.txtHitEnter.Content = "Click the Enter Button below.";
                this.btn_3_Enter_or_Exit.Content = "Enter";
                _isOriginal = true;
            }
        }
    }
}
